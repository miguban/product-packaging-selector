

<?php $__env->startSection('title', "Product Input | Product Packaging Selector"); ?>

<?php $__env->startSection('content'); ?>

<?php if(Session::has('error')): ?>
<div class="alert alert-danger mb-4" role="alert">
    <h3 class="mb-3">ERROR</h3>
  <ul>
  <?php echo Session::get('error'); ?>

  </ul>
</div>
<?php endif; ?>


<?php if(Session::has('success')): ?>
<div class="alert alert-success mb-4" role="alert">
  <h3 class="mb-3">RESULTS</h3>
  <ul>
  <?php echo Session::get('success'); ?>

  </ul>
</div>
<?php endif; ?>

<h5>Product Input</h5>
<hr>
 <form action="/submitProductInput" method="post" id="productInputForm">
  <?php echo csrf_field(); ?>
<div id="dProductDiv" class="my-4" style="max-width: 30em;">
 

<label class="fw-bold mb-3">PRODUCT 1</label>
    <div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Product Name</span>
  <input type="text" class="form-control" name="productName[]">
</div>

    <div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Length (cm)</span>
  <input type="number" class="form-control" name="productLength[]">
</div>

<div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Width (cm)</span>
  <input type="number" class="form-control" name="productWidth[]">
</div>


<div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Height (cm)</span>
  <input type="number" class="form-control" name="productHeight[]">
</div>


<div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Weight (kg)</span>
  <input type="number" class="form-control" name="productWeight[]">
</div>

<div class="input-group mb-3">
  <span class="input-group-text bg-secondary text-white w-9em">Quantity (pcs)</span>
  <input type="number" class="form-control" name="productQuantity[]">
</div>


</div>
</form>


<div style="text-align: end; max-width: 30em;">
  <button type="button" class="btn btn-outline-dark" id="addProductButton" onclick="addAnotherProduct();">+ Add another product</button>
  <button type="submit" class="btn btn-success" onclick="$('#productInputForm').submit();">Submit</button>
</div>

<?php $__env->stopSection(); ?>

<script type="text/javascript">
  
  var productNumber = 1;

  function addAnotherProduct () {
    
    console.log(productNumber+1);

    if (productNumber <= 9) {

    var productNumberIncrement = ++productNumber;

    var newProductEntry = '<div id="newProductDiv'+productNumberIncrement+'"><label class="fw-bold mb-3 mt-3">PRODUCT <span>'+productNumberIncrement+'</span></label><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Product Name</span><input type="text" class="form-control" name="productName[]"></div><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Length (cm)</span><input type="number" class="form-control" name="productLength[]"></div><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Width (cm)</span><input type="number" class="form-control" name="productWidth[]"></div><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Height (cm)</span><input type="number" class="form-control" name="productHeight[]"></div><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Weight (kg)</span><input type="number" class="form-control" name="productWeight[]"></div><div class="input-group mb-3"><span class="input-group-text bg-secondary text-white w-9em">Quantity (pcs)</span><input type="number" class="form-control" name="productQuantity[]"></div></div>\r\n';

    document.getElementById('dProductDiv').insertAdjacentHTML('beforeend', newProductEntry);;    


    }

    if (productNumber == 10) {
      $('#addProductButton').hide();
    }

  
    $('html, body').animate({
        scrollTop: $("#newProductDiv"+productNumberIncrement).offset().top
    });


  }



  

</script>

<style>
  .w-9em {
    width: 9em;
  }
</style>
<?php echo $__env->make('templates.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\migue\Documents\Dev Files\ProductPackagingSelector-Machship\resources\views/product_input_results.blade.php ENDPATH**/ ?>